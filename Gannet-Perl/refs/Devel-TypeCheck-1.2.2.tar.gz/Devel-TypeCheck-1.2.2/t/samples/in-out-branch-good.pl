# pass
if (int(rand(2)) % 2) {
    $foo = 1;
}

$foo = 2;
