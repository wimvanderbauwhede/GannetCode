# fail
$foo = 1;
$foo = "foo";
