# pass
if (int(rand(2)) % 2) {
    $foo = 1;
    1;
} else {
    $bar = "foo";
    1;
}
