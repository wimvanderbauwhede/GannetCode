# fail
$foo = "foo";
$bar = $foo;
$bar = 1;
