exit 0;
# pass
#$bar = "bar\n";
#$foo = *bar{GLOB};
#print ${*{$foo}};
