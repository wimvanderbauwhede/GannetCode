# pass
$foo = "foo";
$bar = $foo;
