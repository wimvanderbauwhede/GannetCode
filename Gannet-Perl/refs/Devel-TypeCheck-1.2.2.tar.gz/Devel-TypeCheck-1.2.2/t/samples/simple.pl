# pass
$foo = 1;
